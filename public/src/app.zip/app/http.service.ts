import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) {
  }

  getTasks() {
    return this._http.get('/tasks');
  }

  getTask(id) {
    return this._http.get('/tasks/' + id);
  }

  addTask(new_task) {
    return this._http.post('/tasks/', new_task);
  }

  editTask(id, updated_task) {
    return this._http.put('/tasks/' + id, updated_task);
  }

  deleteTask(id) {
    return this._http.delete('/tasks/' + id);
  }
}

