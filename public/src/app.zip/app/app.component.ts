import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';
import { observable } from 'rxjs';
import { formArrayNameProvider } from '@angular/forms/src/directives/reactive_directives/form_group_name';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  title = 'MEAN';
  tasks = [];
  one_task;
  newTask: any;
  editTask: any;
  check_id;

  button_task;
  button_tasks;

  can_edit = false;

  constructor(private _httpService: HttpService) {
  }

  ngOnInit() {
    this.getTasksFromService();
    this.newTask = {title: "", description: ""};
    this.editTask = {title: "", description: ""};
  }

  getTasksFromService() {
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
      console.log("Retrieving all tasks: " + data);
      this.tasks = data['data'];
    });
  }

  onButtonClick_ShowTasks() {
    console.log(`Showing all tasks!`);
    this.button_tasks = this.tasks;
  }

  onButtonClick_ShowSpecificTask(this_task) {
    console.log("Showing Task!!");
    console.log(this_task);
    let observable = this._httpService.getTask(this_task);
    observable.subscribe(data => {
      console.log("Retrieving all tasks: " + data);
      this.one_task = data['data'];
    });
  }

  onSubmit() {
    let observable = this._httpService.addTask(this.newTask);
    observable.subscribe(data => {
      console.log("Got our data from post: " + data);
      this.newTask = { title: "", description: "" }
    })
  }

  showEditor(task_id) {
    if(this.can_edit === true) {
      this.can_edit = false;
      console.log("Now the can_edit variable is set to..." + this.can_edit);
      this.check_id=undefined;
    }
    else {
      console.log("Clicked on edit button!");
      console.log("Now the can_edit variable is set to..." + this.can_edit);
      this.can_edit = true;
      this.check_id = task_id;
    }
  }

  onEdit(task_id) {
    console.log("Hopefully Editing Task: " + this.editTask.title +" "+ this.editTask.description);

    let observable = this._httpService.editTask(task_id, this.editTask);
    observable.subscribe(data => {

      console.log("Hopefully Editing Task: " + data);
    })
  }

  deleteTask(task_id) {
    let observable = this._httpService.deleteTask(task_id);
    observable.subscribe(data => {
      console.log("Hopefully Deleting Task: " + data);
    })
  }
}
